package com.example.gta5trainer

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class FloatingTrainerService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var collapsed = false
    private val accent = Color.rgb(238, 48, 55)
    private val pages = listOf("PLAYER", "VEHICLES", "WORLD", "CHEATS")

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun startAsForeground() {
        val channelId = "trainer_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Trainer overlay",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId)
        else Notification.Builder(this)
        val n = notification.setContentTitle("GTA V Trainer")
            .setContentText("Floating trainer is running")
            .setSmallIcon(android.R.drawable.ic_menu_manage).build()
        startForeground(7, n)
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 12)
            background = rounded(Color.rgb(20, 22, 29), 18)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "V  GTA V TRAINER"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val minimize = TextView(this).apply {
            text = "—"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(12, 0, 12, 0)
            setOnClickListener { toggleCollapsed(root) }
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(10, 0, 4, 0)
            setOnClickListener { stopSelf() }
        }
        header.addView(title); header.addView(minimize); header.addView(close)
        root.addView(header)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content)
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 10, 0, 8)
        }
        pages.forEach { page ->
            val tab = TextView(this).apply {
                text = page
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(7, 9, 7, 9)
                background = rounded(accent, 8)
                setOnClickListener { renderPage(content, page) }
            }
            tabs.addView(tab, LinearLayout.LayoutParams(0, -2, 1f).apply {
                setMargins(2, 0, 2, 0)
            })
        }
        content.addView(tabs)
        renderPage(content, "PLAYER")
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >=  O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 120 }
        header.setOnTouchListener(DragTouchListener(params))
        panel = root
        windowManager.addView(root, params)
    }

    private fun renderPage(container: LinearLayout, page: String) {
        while (container.childCount > 1) container.removeViewAt(1)
        val rows = when (page) {
            "PLAYER" -> listOf(
                "Change player skin" to "Select a character skin",
                "Set money amount" to "Enter amount in the connected mod API",
                "Restore health / armor" to "Single-player action hook"
            )
            "VEHICLES" -> listOf(
                "Spawn vehicle" to "Choose a supported vehicle model",
                "Repair current vehicle" to "Vehicle repair action hook",
                "Vehicle modifications" to "Engine • Turbo • Brakes • Suspension",
                "Change vehicle paint" to "Paint and wheel customization"
            )
            "WORLD" -> listOf(
                "Teleport to waypoint" to "Teleport action hook",
                "Teleport: city center" to "Preset location hook",
                "Unlock city areas" to "Map unlock action hook"
            )
            else -> listOf(
                "Unlock all cheats" to "Cheat unlock action hook",
                "Never wanted" to "Single-player cheat hook",
                "Weather / time" to "World settings action hook"
            )
        }
        rows.forEach { (label, detail) ->
            val button = Button(this).apply {
                text = "$label\n$detail"
                textSize = 12f
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = rounded(Color.rgb(45, 48, 59), 10)
                setOnClickListener {
                    Toast.makeText(this@FloatingTrainerService,
                        "$label: demo only — connect a compatible game mod API",
                        Toast.LENGTH_LONG).show()
                }
            }
            container.addView(button, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 4, 0, 4)
            })
        }
        val note = TextView(this).apply {
            text = "UI template only • no game memory editing or injection included"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(4, 8, 4, 0)
        }
        container.addView(note)
    }

    private fun toggleCollapsed(root: LinearLayout) {
        collapsed = !collapsed
        if (collapsed) {
            if (root.childCount > 1) root.removeViewAt(1)
        } else {
            val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            root.addView(content)
            renderPage(content, "PLAYER")
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    override fun onDestroy() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class DragTouchListener(
        private val params: WindowManager.LayoutParams
    ) : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(v, params)
                    return true
                }
            }
            return false
        }
    }

    companion object { private const val O = 26 }
}
