package com.example.gta5trainer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var statusMods: TextView
    private lateinit var statusAccess: TextView
    private var modsEnabled = false
    private var openIvEnabled = true
    private var trainerEnabled = true

    private val bg = Color.rgb(34, 42, 92)
    private val panel = Color.rgb(91, 111, 153)
    private val accent = Color.rgb(218, 76, 119)
    private val cyan = Color.rgb(0, 190, 211)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildDashboard()
        refreshStatus()
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
        }
        scroll.addView(page)

        page.addView(text("OpenIV GTA V Mods", 29, Color.WHITE, true))
        page.addView(text("Mod & DLC loader companion for supported GTA V Android ports", 14, 0xFFD8D9EA.toInt()))
        page.addView(text("Trainer dashboard • Android 16", 14, Color.WHITE, true).apply {
            setPadding(0, 12, 0, 20)
        })

        val status = card()
        status.addView(section("SYSTEM STATUS"))
        statusAccess = text("●  Privileged access     Checking…", 15, Color.WHITE, true)
        status.addView(statusAccess)
        status.addView(text("●  GTA V port                 Installed (v1.61.1*)", 15, Color.rgb(0, 220, 174), true))
        statusMods = text("●  Mods                         Disabled (clean game)", 15, Color.LTGRAY, true)
        status.addView(statusMods)
        page.addView(status)

        val options = card()
        options.addView(section("OPTIONS"))
        options.addView(toggleRow("OpenIV support", "Redirect supported game files to mods/", openIvEnabled) {
            openIvEnabled = it
            log(if (it) "OpenIV support enabled in UI" else "OpenIV support disabled in UI")
        })
        options.addView(toggleRow("In-game trainer", "Floating menu over the game", trainerEnabled) {
            trainerEnabled = it
            log(if (it) "In-game trainer enabled" else "In-game trainer disabled")
        })
        page.addView(options)

        val actions = card()
        actions.addView(actionButton("Enable mods & launch game", accent) {
            if (!hasOverlayPermission()) {
                log("Overlay permission required before starting the floating trainer")
                requestOverlayPermission()
            } else {
                modsEnabled = true
                refreshStatus()
                log("Demo only: mod activation requires a compatible port integration and privileged file access")
                if (trainerEnabled) startService(Intent(this, FloatingTrainerService::class.java))
            }
        })
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(actionButton("Disable mods", Color.rgb(139, 91, 89)) {
            modsEnabled = false
            refreshStatus()
            log("Mods disabled in trainer UI; no game files were changed")
        }, weight())
        row1.addView(actionButton("Fix permissions", Color.rgb(85, 91, 137)) {
            if (!hasOverlayPermission()) requestOverlayPermission()
            else log("Overlay permission is granted; root/Shizuku file access is not available")
        }, weight())
        actions.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(actionButton("RPF editor", Color.rgb(105, 82, 132)) {
            log("RPF editor is a placeholder: a compatible RPF library and port access are required")
        }, weight())
        row2.addView(actionButton("Refresh log", Color.rgb(85, 91, 137)) {
            log("Log refreshed")
        }, weight())
        actions.addView(row2)
        page.addView(actions)

        val activity = card()
        activity.addView(section("ACTIVITY LOG"))
        logView = text("Waiting for actions…", 14, Color.rgb(120, 240, 209))
        logView.setPadding(12, 16, 12, 16)
        logView.background = rounded(Color.rgb(37, 43, 76), 14)
        activity.addView(logView)
        page.addView(activity)

        page.addView(text("*Port version shown from your screenshot; verify it in your installed game.", 11, Color.LTGRAY))
        page.addView(text("This companion currently provides the interface only. It does not patch game memory or modify RPF files.", 12, Color.WHITE).apply {
            setPadding(2, 12, 2, 0)
        })
        setContentView(scroll)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 18, 18, 18)
        background = rounded(panel, 22)
        alpha = 0.96f
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 12, 0, 12)
        layoutParams = lp
    }

    private fun section(s: String) = text(s, 12, 0xFFD9D8EE.toInt(), true).apply {
        letterSpacing = 0.16f
        setPadding(0, 0, 0, 14)
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 5, 0, 5)
        }

    private fun toggleRow(title: String, subtitle: String, initial: Boolean, changed: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 8)
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text(title, 16, Color.WHITE, true))
        labels.addView(text(subtitle, 12, 0xFFD5D3E7.toInt()))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            isChecked = initial
            buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
            setOnCheckedChangeListener { _, checked -> changed(checked) }
        }
        row.addView(sw)
        return row
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.WHITE)
            background = rounded(color, 18)
            setPadding(8, 12, 8, 12)
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 7, 6, 7)
            layoutParams = lp
        }

    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f)

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(1, 0x99FFFFFF.toInt())
    }

    private fun hasOverlayPermission() = Settings.canDrawOverlays(this)

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")))
    }

    private fun refreshStatus() {
        val access = hasOverlayPermission()
        statusAccess.text = if (access)
            "●  Overlay access             Granted; root/Shizuku unavailable"
        else "●  Privileged access     Shizuku/root unavailable; overlay permission needed"
        statusAccess.setTextColor(if (access) Color.rgb(255, 190, 80) else Color.rgb(255, 128, 151))
        statusMods.text = if (modsEnabled) "●  Mods                         Enabled (UI demo only)"
            else "●  Mods                         Disabled (clean game)"
    }

    private fun log(message: String) {
        if (::logView.isInitialized) {
            val previous = logView.text.toString()
            logView.text = "› $message\n$previous".take(1400)
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        if (::statusAccess.isInitialized) refreshStatus()
    }
}
