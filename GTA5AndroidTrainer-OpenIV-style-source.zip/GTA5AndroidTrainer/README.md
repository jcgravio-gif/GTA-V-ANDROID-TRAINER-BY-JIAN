# GTA V Android Trainer — OpenIV-style dashboard UI

Android Studio Kotlin source project. The dashboard follows the supplied reference: system status, OpenIV support and in-game trainer toggles, enable/disable actions, permission helper, RPF editor placeholder, activity log, and a floating trainer overlay.

## Port details
The supplied screenshot reports GTA V port v1.61.1. This is displayed as a reference label, not independently detected or verified by the app.

## Important functionality boundary
This is a UI starter, not a functioning OpenIV loader or game trainer. The controls currently update the app's UI/log and can launch the floating overlay. They do not redirect game files, modify RPF archives, grant root/Shizuku access, inject code, patch game memory, change money/skins, spawn vehicles, or unlock the map. Those require a documented integration supported by the exact GTA V port and the required privileged access. The screenshot itself reports root and Shizuku unavailable.

## Build
1. Open this folder in Android Studio with JDK 17.
2. Allow Gradle sync (Android Gradle Plugin 8.10.1; compile SDK 36 required).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk`.
5. Grant Display over other apps to use the floating trainer.
